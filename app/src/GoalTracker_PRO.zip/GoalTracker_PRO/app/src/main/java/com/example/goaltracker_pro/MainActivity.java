package com.example.goaltracker_pro;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.goaltracker_pro.databinding.ActivityMainBinding;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int RC_SIGN_IN = 9001;
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private SQLiteDatabase db;
    private ListView lv;
    private int idd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //init
        mAuth = FirebaseAuth.getInstance();

        com.example.goaltracker_pro.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = getBaseContext().openOrCreateDatabase("app.db", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS tasx (id INTEGER, name TEXT, complOn INTEGER, steps INTEGER, dates TEXT)");
        db.execSQL("DROP TABLE tasx");
//        db.execSQL("INSERT OR IGNORE INTO tasks VALUES ('t1', 23), ('t2', 31);");

        lv = findViewById(R.id.lv);
        FloatingActionButton fab = findViewById(R.id.fab);
        updateDB();
//        updateDB();

//        query.close();
//        db.close();
        //Add Task
        fab.setOnClickListener(v -> {
            Log.d("his","this is click? it`s touch");
            LayoutInflater li = LayoutInflater.from(this);
            View promptsView = li.inflate(R.layout.add_dialog, null);

            //Создаем AlertDialog
            AlertDialog.Builder mDialogBuilder = new AlertDialog.Builder(this);

            //Настраиваем prompt.xml для нашего AlertDialog:
            mDialogBuilder.setView(promptsView);

            //Настраиваем отображение поля для ввода текста в открытом диалоге:
            final EditText inputName = (EditText) promptsView.findViewById(R.id.input_text);
            final EditText inpuSteps = (EditText) promptsView.findViewById(R.id.taskSteps);
            final EditText inputCompleted = (EditText) promptsView.findViewById(R.id.taskComplete);

            //Настраиваем сообщение в диалоговом окне:
            mDialogBuilder
                    .setCancelable(false)
                    .setPositiveButton("OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {
                                    //Вводим текст и отображаем в строке ввода на основном экране:
                                    String a = ("'");
                                    Log.d("message",inputName.getText().toString() + inpuSteps.getText());
                                    long d = System.currentTimeMillis();
                                    db.execSQL("INSERT OR IGNORE INTO tasx VALUES ("+idd+", " +
                                            a + inputName.getText().toString() +a +", "+a +inpuSteps.getText() +a+", "+a+ inputCompleted.getText()+a+","+ String.valueOf(d) +");");
                                    updateDB();
//                                    final_text.setText(userInput.getText());
                                }
                            })
                    .setNegativeButton("Отмена",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {
                                    dialog.cancel();
                                }
                            });

            //Создаем AlertDialog:
            AlertDialog alertDialog = mDialogBuilder.create();

            //и отображаем его:
            alertDialog.show();
        });
        lv.setOnItemClickListener((parent, view, position, id) -> onCompliteTask((int) id));
        lv.setOnItemLongClickListener((parent, view, position, id) -> {
            Intent i = new Intent(MainActivity.this, Stats.class);
            i.putExtra("id", id);
            startActivity(i);
            return false;
        });
//        db.close();
//        FirebaseFirestore db = FirebaseFirestore.getInstance();
////        db.collection("test").add("testText").addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
////            @Override
////            public void onSuccess(DocumentReference documentReference) {
////                Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
////            }
////        }).addOnFailureListener(new OnFailureListener() {
////            @Override
////            public void onFailure(@NonNull Exception e) {
////                Log.w(TAG, "Error adding document", e);
////            }
////        });
//        db.collection("test").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
//            @Override
//            public void onComplete(@NonNull Task<QuerySnapshot> task) {
//                if (task.isSuccessful()){
//                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
//                        tw.setText(documentSnapshot.getId() + " " + documentSnapshot.getData());
//                    }
//                }
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Log.w(TAG, "Error getting documents." + e.getMessage());
//            }
//        });

        SignInButton mSignInButton = findViewById(R.id.sign_in_button);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
            mSignInButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Запускаем намерение для входа
                    Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                    startActivityForResult(signInIntent, RC_SIGN_IN);
                }
            });
    }


    private void updateDB(){
        ArrayList<DataModel> list = new ArrayList<>();
        Cursor query = db.rawQuery("SELECT * FROM tasx;", null);
        CustomAdapter adapter = new CustomAdapter(list, getApplicationContext());
        while(query.moveToNext()){
            String id = query.getString(4);
            String name = query.getString(1);
            String age = String.valueOf(query.getInt(2));
            String stp = String.valueOf(query.getInt(3));
            Integer a = Integer.valueOf(age);
            Integer b = Integer.valueOf(stp);
            Float prgrs = (((float)a/b)*100);
            Log.d("prgrs", stp+age+String.valueOf(prgrs));
            list.add(new DataModel(name, age, stp, "последнее: "+id, prgrs.intValue()));
        }
        lv.setAdapter(adapter);
        idd = list.size();
        Log.d("asd", String.valueOf(idd));
//        query.close();
    }

    private void onCompliteTask(Integer i){
            ContentValues values = new ContentValues();
            values.put("complOn =", "complOn+1");
//            db.update("tasx", values, "id = '"+ i+"'", null);
            db.execSQL("UPDATE tasx SET complOn = complOn + 1, dates = dates || "+ System.currentTimeMillis() +" WHERE id = "+ i);
            Log.d("click","successuful" + i);
//            db.delete("tasx", "id='" +i+ "' AND complOn >= steps", null);
            db.execSQL("DELETE FROM tasx WHERE id = "+i+" AND complOn >= steps");
            Log.d("click","successuful" + i);

        updateDB();
//        updateDB();
    }

    @Override
    public void onStart() {
        super.onStart();
        // Проверяем, вошел ли пользователь, и обновляем интерфейс
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Обрабатываем результат намерения для входа
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Вход успешен, аутентифицируемся с Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Вход не удался, выводим сообщение об ошибке
                Log.w(TAG, "Google sign in failed", e);
                Toast.makeText(this, "Google sign in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                updateUI(null);
            }
        }
    }
    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
    Log.d(TAG, "firebaseAuthWithGoogle:" + acct.getId());

    // Получаем учетные данные
    AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
    // Входим с помощью учетных данных
    mAuth.signInWithCredential(credential)
            .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        // Вход успешен, обновляем интерфейс с данными пользователя
                        Log.d(TAG, "signInWithCredential:success");
                        FirebaseUser user = mAuth.getCurrentUser();
                        updateUI(user);
                    } else {
                        // Вход не удался, выводим сообщение об ошибке
                        Log.w(TAG, "signInWithCredential:failure", task.getException());
                        Toast.makeText(MainActivity.this, "Authentication failed: " + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                        updateUI(null);
                    }
                }
            });
}

    private void updateUI(FirebaseUser user) {

        if (user != null) {

            String name = user.getDisplayName();
            String email = user.getEmail();
            String photo = Objects.requireNonNull(user.getPhotoUrl()).toString();

        } else {
            Log.d("asd","qwe");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
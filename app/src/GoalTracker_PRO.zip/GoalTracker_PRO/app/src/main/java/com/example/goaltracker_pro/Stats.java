package com.example.goaltracker_pro;// Импортируем необходимые библиотеки

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.spans.DotSpan;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Stats extends AppCompatActivity {

    MaterialCalendarView calendarView = findViewById(R.id.cvv);
    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);
        Bundle b = getIntent().getExtras();
        assert b != null;
        Integer id = b.getInt("id");
        db = getBaseContext().openOrCreateDatabase("app.db", MODE_PRIVATE, null);
        Cursor query = db.rawQuery("SELECT id = "+id+" FROM tasx;", null);
        String d = query.getString(4);

//        // Получаем ссылку на календарь по идентификатору
    }
    }

